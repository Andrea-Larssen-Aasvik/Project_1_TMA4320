"""Script for training and plotting the PINN model."""

import os

import jax.numpy as jnp
import matplotlib.pyplot as plt
import numpy as np
from viz import create_animation, plot_snapshots

from project import (
    generate_training_data,
    load_config,
    predict_grid,
    train_pinn,
    )

def main():
    cfg = load_config("config.yaml")

    #######################################################################
    # Oppgave 5.4: Start
    #######################################################################

    # Generer treningsdata
    x, y, t, T_fdm, sensor_data = generate_training_data(cfg)

    # Tren PINN
    pinn_params, history = train_pinn(sensor_data, cfg)

    # Evaluer på grid
    T_pred = predict_grid(pinn_params["nn"], x, y, t, cfg)

    # Visualiser treningsprosessen
    plt.figure()
    plt.plot(history["total"], label="Total Loss")
    plt.plot(history["data"], label="Data Loss")
    plt.plot(history["physics"], label="Physics loss")
    plt.plot(history["ic"], label="IC Loss")
    plt.plot(history["bc"], label="BC Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("PINN Training Loss")
    plt.legend()
    plt.show()

    # Print de lærte fysiske parameterne
    for key, value in pinn_params.items():
        if key[:4] == "log_":
            name = key[4:]
            value = jnp.exp(value[0])
            true_value = getattr(cfg, name, None)
            if true_value is not None:
                print(f"{name}: {value:.4f} (sann verdi er {true_value})")
                print(f"Dette gir en relativ feil på {(100*(abs(value-true_value))/true_value):.2f}%\n")
            else:
                print(f"{name}: {value:.4f}")

    # Visualiser snapshots / animasjon
    plot_snapshots(x, y, t, T_pred, save_path="output/pinn/pinn_snapshots.png")

    # Lager animasjon
    create_animation(x, y, t, T_pred, save_path="output/pinn/pinn_animation.gif")
            
    #######################################################################
    # Oppgave 5.4: Slutt
    #######################################################################

if __name__ == "__main__":
    main()
