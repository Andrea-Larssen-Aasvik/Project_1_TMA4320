"""Script for training and plotting the NN model."""

import os

import jax.numpy as jnp
import matplotlib.pyplot as plt
import numpy as np
from viz import create_animation, plot_snapshots


from project import (
    generate_training_data,
    load_config,
    predict_grid,
    train_nn,
)


def main():
    cfg = load_config("config.yaml")

    #######################################################################
    # Oppgave 4.4: Start
    #######################################################################

    # Generer treningsdata
    x, y, t, T_fdm, sensor_data = generate_training_data(cfg)

    # Tren NN
    nn_params, loss_history = train_nn(sensor_data, cfg)

    total_loss = loss_history["total"]
    data_loss = loss_history["data"]
    ic_loss = loss_history["ic"]

    # Plot tap
    plt.figure()
    plt.plot(total_loss, label="Total loss")
    plt.plot(data_loss, label="Data loss")
    plt.plot(ic_loss, label="IC loss")
    plt.yscale("log")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.title("Training loss history")
    plt.show()

    # Prediker temperatur med NN
    T_nn = predict_grid(nn_params, x, y, t, cfg)

    # Sammenlign med FDM løsning
    t_idx = -1  # siste tidspunkt

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))

    im0 = axes[0].imshow(
        T_fdm[t_idx].T,     #added .T for å transponere matrisen
        origin="lower",
        extent=[x.min(), x.max(), y.min(), y.max()],
        cmap="hot", #farger som gir varme-vibe
    )
    axes[0].set_title("FDM solution")
    plt.colorbar(im0, ax=axes[0])

    im1 = axes[1].imshow(
        T_nn[t_idx].T,      #added .T for å transponere matrisen
        origin="lower",
        extent=[x.min(), x.max(), y.min(), y.max()],
        cmap="hot"
    )
    axes[1].set_title("NN prediction")
    plt.colorbar(im1, ax=axes[1])

    plt.suptitle(f"Temperature field at t = {t[t_idx]:.2f}")
    plt.show()

    # Visualiser snapshots / animasjon
    plot_snapshots(x, y, t, T_nn, save_path="output/nn/nn_snapshots.png")

    # Lager animasjon
    create_animation(x, y, t, T_nn, save_path="output/nn/nn_animation.gif")

    #######################################################################
    # Oppgave 4.4: Slutt
    #######################################################################


if __name__ == "__main__":
    main()
