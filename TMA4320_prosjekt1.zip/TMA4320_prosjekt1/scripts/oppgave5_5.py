"""
Script for Oppgave 5.5: Sammenligning av NN og PINN.
Vi tester robusthet mot antall sensorer og støynivå ved å endre Config.
"""

import sys
from pathlib import Path
from dataclasses import replace
import time

# Legg til src i path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import jax.numpy as jnp
import numpy as np
import matplotlib.pyplot as plt

from project import (
    generate_training_data,
    load_config,
    predict_grid,
    train_nn,
    train_pinn,
)

# # Setter global stil for pene plott
# plt.style.use('hot')

def calculate_error(T_pred, T_true):
    """
    Beregner relativ feil.
    """
    # Unngå deling på null hvis T_true er veldig nær 0
    norm_true = np.linalg.norm(T_true)  
    if norm_true < 1e-6:
        norm_true = 1.0
    return np.linalg.norm(T_pred - T_true) / norm_true

def run_comparison(cfg, test_type=""):
    """
    Kjører NN og PINN på samme data og returnerer feil og prediksjoner.
    """
    print(f"\n--- Starter sammenligning: {test_type} ---")
    
    # 1. Generer data (Basert på den endrede config-en, se lenger ned)
    x, y, t, T_fdm, sensor_data = generate_training_data(cfg)
    
    #finner hvor mange sensorer = antall rader pga. matrise form
    num_sensors = cfg.sensor_locations.shape[0] 
    print(f"Antall sensorer: {num_sensors}")
    print(f"Støynivå (std):  {cfg.sensor_noise}")

    # Kopiert fra run_pinn.py
    # Gjør klar data for PINN
    T_fdm_aligned = jnp.moveaxis(T_fdm, 0, -1)

    # 3. Tren Standard NN (kun sensordata)
    print("Trener Standard NN")
    nn_params, _ = train_nn(sensor_data, cfg)
    print("NN ferdig")

    # 4. Tren PINN (grid og fysikk)
    print("Trener PINN")
    pinn_params, _ = train_pinn(sensor_data, cfg)   #endret fra pinn_data til sensor_data her nå
    print("PINN ferdig")

    # 5. Evaluer begge modellene
    T_nn_raw = predict_grid(nn_params, x, y, t, cfg) # obs! (t, x, y)
    T_pinn_raw = predict_grid(pinn_params["nn"], x, y, t, cfg) # obs! (t, x, y)

    # Vi flytter t (akse 0) til slutten (akse -1)
    T_nn = jnp.moveaxis(T_nn_raw, 0, -1)
    T_pinn = jnp.moveaxis(T_pinn_raw, 0, -1)

    # Regner ut feilen med funksjon definert over
    err_nn = calculate_error(T_nn, T_fdm_aligned)
    err_pinn = calculate_error(T_pinn, T_fdm_aligned)

    # Skriver ut feil i %
    print(f"Feil NN: {err_nn:.4f} ({err_nn*100:.2f}%)")
    print(f"Feil PINN: {err_pinn:.4f} ({err_pinn*100:.2f}%)")

    # Print de lærte fysiske parameterne
    learned_params = {}
    for key, value in pinn_params.items():
        if key[:4] == "log_":
            name = key[4:]
            value = jnp.exp(value[0])
            learned_params[name] = value
            true_value = getattr(cfg, name, None)
            if true_value is not None:
                print(f"\n{name}: {value:.4f} (sann verdi er {true_value})")
                print(f"Dette gir en relativ feil på {(100*(abs(value-true_value))/true_value):.2f}%")
            else:
                print(f"{name}: {value:.4f}")

    return T_nn, T_pinn, T_fdm_aligned, err_nn, err_pinn, x, y, t, learned_params

def plot_comparison(T_nn, T_pinn, T_fdm, x, y, t, title):
    """
    Plotter FDM, NN og PINN side om side ved siste tidspunkt.
    """
    t_idx = -1  # Siste tidspunkt
    
    fig, axes = plt.subplots(1, 3, figsize=(15, 5), constrained_layout=True)
    
    # Finn felles min/max slik at fargeskala blir samme på alle
    vmin = T_fdm.min()
    vmax = T_fdm.max()
    
    # Dataene må transponeres (.T) fordi imshow bytter om x og y
    data_list = [
        (T_fdm[:,:, t_idx].T, "FDM"),
        (T_nn[:,:, t_idx].T, "NN"),
        (T_pinn[:,:, t_idx].T, "PINN")
    ]
    im = None #får problem om den ikke defineres først

    for ax, (data, label) in zip(axes, data_list):
        im = ax.imshow(
            data, 
            origin="lower", 
            extent=[x.min(), x.max(), y.min(), y.max()],
            cmap="hot", 
            vmin=vmin, vmax=vmax, 
        )
        ax.set_title(label, fontsize=14)
        ax.set_xlabel("x (m)")
        
        # Kun y-akse på første plott
        if label == "Fasit (FDM)": 
            ax.set_ylabel("y (m)")
        else: 
            ax.set_yticks([])
    if im is not None:  #får problem ellers
        cbar = fig.colorbar(im, ax=axes, shrink=0.8, location="right")
        cbar.set_label("Temperatur")
    fig.suptitle(title, fontsize=16)
    plt.show()

def main():
    base_cfg = load_config("config.yaml") 

    #################################################################
    # SCENARIO 1: Ingen endring av parametrene i config.yaml
    #################################################################

    print("\nSCENARIO 1: INGEN ENDRING I PARAMETRE")

    resultat = run_comparison(base_cfg, test_type="Ingen endring")

    T_nn, T_pinn, T_fdm, err_nn, err_pinn, x, y, t, lp = resultat  #lp = learned_params
    
    plot_comparison(T_nn, T_pinn, T_fdm, x, y, t, "Sammenligning: Ingen endring av parametre")

    #################################################################
    # SCENARIO 2: Lite data (Få sensorer)
    #################################################################

    print("\nSCENARIO 2: FÅ SENSORER")
    
    # Vi velger ut bare de 3 første sensorene fra listen i config (midten og to hjørner)
    few_sensors = base_cfg.sensor_locations[:3]
    
    # Lager ny config med færre sensorer
    cfg_few_sensors = replace(
        base_cfg, 
        sensor_locations=few_sensors,
    )
    
    res_few_sensors = run_comparison(cfg_few_sensors, test_type="Kun 3 Sensorer")
    T_nn, T_pinn, T_fdm, err_nn, err_pinn, x, y, t, lp_few_sensors = res_few_sensors
    
    plot_comparison(T_nn, T_pinn, T_fdm, x, y, t, "Sammenligning: Kun 3 sensorer")


    #################################################################
    # SCENARIO 3: Mye data (Mange sensorer)
    #################################################################

    print("\nSCENARIO 3: MANGE SENSORER")
    
    # Finner på punkter
    many_sensors = jnp.asarray([
        [5.0, 2.5], #midten
        [5.0, 5.0], 
        [5.0, 0.0], #hjørner og vegger
        [0.0, 2.5],
        [10.0, 2.5],
        [0.0, 0.0],
        [0.0, 5.0],
        [10.0, 0.0],
        [10.0, 5.0],
        [7.5, 0.0], #legger til punkter rundt omkring
        [7.5, 5.0],
        [2.5, 0.0],
        [2.5, 5.0],
        [0.0, 1.25],
        [5.0, 1.25],
        [0.0, 3.75],
        [5.0, 3.75],
        [2.5, 1.25],
        [2.5, 3.75],
        [7.5, 1.25],
        [7.5, 3.75],
        [2.5, 2.5],
        [7.5, 2.5],
        [10.0, 1.25],
        [10, 3.75]
        ])
    
    # Lager ny config med færre sensorer
    cfg_many_sensors = replace(
        base_cfg, 
        sensor_locations=many_sensors,
    )
    
    res_many_sensors = run_comparison(cfg_many_sensors, test_type="25 Sensorer")
    T_nn, T_pinn, T_fdm, err_nn, err_pinn, x, y, t, lp_many_sensors = res_many_sensors
    
    plot_comparison(T_nn, T_pinn, T_fdm, x, y, t, "Sammenligning: 25 sensorer")


    #################################################################
    # SCENARIO 4: Mye støy
    #################################################################
    print("\nSCENARIO 4: MYE STØY")
    
    # Øker sensor_noise kraftig
    # Endrer noise fra 0.5 til 3.0 
    cfg_noise = replace(
        base_cfg, 
        sensor_noise=5.0, 
    )
    
    res_noise = run_comparison(cfg_noise, test_type="Høy støy")
    T_nn, T_pinn, T_fdm, err_nn, err_pinn, x, y, t, lp_noise = res_noise
    
    plot_comparison(T_nn, T_pinn, T_fdm, x, y, t, "Sammenligning: Høy støy")


    #################################################################
    # SCENARIO 5: Lite støy, mange sensorer
    #################################################################

    print("\nSCENARIO 5: MANGE SENSORER, LITE STØY")
    
    # Finner på punkter
    # Lager ny config med færre sensorer
    cfg_many_sensors_less_noise = replace(
        base_cfg, 
        sensor_locations=many_sensors,
        sensor_noise=0.1
    )
    
    res_many_sensors_less_noise = run_comparison(cfg_many_sensors_less_noise, test_type="25 Sensorer, lav støy")
    T_nn, T_pinn, T_fdm, err_nn, err_pinn, x, y, t, lp_many_sensors_less_noise = res_many_sensors_less_noise
    
    plot_comparison(T_nn, T_pinn, T_fdm, x, y, t, "Sammenligning: 25 sensorer, lav støy")


    #################################################################
    # OPPSUMMERING (Sammenligner parametre + bar plot)
    #################################################################
    print("\n" + "-"*95)
    print("SAMMENLIGNING AV PARAMETRE")
    print("-"*95)
    print(f"{'Parameter':<14} | {'Sann verdi':<14} | {'Ingen endring':<14} | ", end="")
    print(f"{'Få sensorer':<14} | {'Mange sensorer':<14} | {'Mye støy':<14} | {"Lav støy, mange sensorer"}")
    print("-" * 95)
    fasit = {
        "alpha":  0.25,
        "k":      0.04,
        "h":      0.00,
        "power":  15.0  
    }
    param_keys = list(lp.keys())
    for k in param_keys:
        
        # Finn sann verdi i listen vår (bruker -999 hvis navnet er ukjent)
        sann = fasit.get(k, -999.0)
        
        # Hent verdier for hvert scenario fra de ulike ordbøkene
        v_basis = lp.get(k, 0.0)
        v_faa   = lp_few_sensors.get(k, 0.0)
        v_many  = lp_many_sensors.get(k, 0.0)
        v_stoy  = lp_noise.get(k, 0.0)
        v_msls  = lp_many_sensors_less_noise.get(k, 0.0)

        # Print raden pent formatert
        print(f"{k:<14} | {sann:<14.4f} | {v_basis:<14.4f} | {v_faa:<14.4f} | {v_many:<14.4f} | {v_stoy:<14.4f} | {v_msls:<14.4f}")
    print("-" * 95)

    labels = ["Ingen endring", "Få sensorer", "Mange sensorer", "Mye Støy", "25 sens, lav støy"]
    nn_errors = [resultat[3], res_few_sensors[3], res_many_sensors[3], res_noise[3], res_many_sensors_less_noise[3]]
    pinn_errors = [resultat[4], res_few_sensors[4], res_many_sensors[4], res_noise[4], res_many_sensors_less_noise[4]]

    x_axis = np.arange(len(labels))
    width = 0.35

    plt.figure(figsize=(8, 6))
    plt.bar(x_axis - width/2, nn_errors, width, label="NN")
    plt.bar(x_axis + width/2, pinn_errors, width, label="PINN")
    
    plt.ylabel("Relativ Feil")
    plt.title("NN vs PINN i ulike scenarioer")
    plt.xticks(x_axis, labels)
    plt.legend()
    plt.grid(axis='y', alpha=0.3)
    plt.show()

if __name__ == "__main__":
    main()