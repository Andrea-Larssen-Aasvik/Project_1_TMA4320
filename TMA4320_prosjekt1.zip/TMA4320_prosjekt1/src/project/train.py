"""Training routines for NN and PINN models."""

import jax
import jax.numpy as jnp
from jax import jit
from tqdm import tqdm

from .config import Config
from .loss import bc_loss, data_loss, ic_loss, physics_loss
from .model import init_nn_params, init_pinn_params
from .optim import adam_step, init_adam
from .sampling import sample_bc, sample_ic, sample_interior


def train_nn(
    sensor_data: jnp.ndarray, cfg: Config
) -> tuple[list[tuple[jnp.ndarray, jnp.ndarray]], dict]:
    """Train a standard neural network on sensor data only.

    Args:
        sensor_data: Sensor measurements [x, y, t, T]
        cfg: Configuration

    Returns:
        params: Trained network parameters
        losses: Dictionary of loss histories
    """
    key = jax.random.key(cfg.seed)
    nn_params = init_nn_params(cfg)
    adam_state = init_adam(nn_params)

    losses = {"total": [], "data": [], "ic": []}  # Fill with loss histories

    #######################################################################
    # Oppgave 4.3: Start
    #######################################################################

    # Update the nn_params and losses dictionary

    # 2. Objektivfunksjonen, L(theta)
    def objective_fn(nn_params, ic_epoch):
        # tap for sensordata
        l_data = data_loss(nn_params, sensor_data, cfg) 

        # tap for ic
        l_ic = ic_loss(nn_params, ic_epoch, cfg)

        # regner ut vektet tap etter ligning (9) under 5.2
        l_total = cfg.lambda_data * l_data + cfg.lambda_ic * l_ic

        return l_total, (l_data, l_ic)


    #bruker just in time for å evaluere raskere
    @jit 
    def train_step(nn_params, ic_epoch, adam_state):
        # 2. Evaluer objektivfunksjon og dens gradient
        # bruker jax.value_and_grad (se jax_intro.ipynb)
        # finner verdien og gradienten til objektivfunksjonen når man tar inn parametre nn_params og ic_epoch
        (l_total, (l_data, l_ic)), grads = jax.value_and_grad(objective_fn, has_aux=True)(nn_params, ic_epoch)

        # 3. Oppdaterer parametre ved å ta steg i Adam-algoritme
        # adam_state: vekter som oppdateres for hvert steg
        # grads: gradienten av objective_fn med respekt til nn_params
        nn_params, adam_state = adam_step(nn_params, grads, adam_state, lr=cfg.learning_rate)

        return nn_params, adam_state, l_total, l_data, l_ic
    

    # Tar med fin progress-bar:)
    for _ in tqdm(range(cfg.num_epochs), desc="Training NN"):
        # 1. Sampler posisjoner hvor ic (initial conditions) skal evalueres
        ic_epoch, key = sample_ic(key, cfg)

        # kaller jit-evaluerte funksjonen
        nn_params, adam_state, l_total, l_data, l_ic = train_step(nn_params, ic_epoch, adam_state)

        # 4. Lagrer tapene for logging (inni løkken så gjøres hver epoke)
        losses["total"].append(float(l_total))
        losses["data"].append(float(l_data))
        losses["ic"].append(float(l_ic))

    #######################################################################
    # Oppgave 4.3: Slutt
    #######################################################################

    return nn_params, {k: jnp.array(v) for k, v in losses.items()}


def train_pinn(sensor_data: jnp.ndarray, cfg: Config) -> tuple[dict, dict]:
    """Train a physics-informed neural network.

    Args:
        sensor_data: Sensor measurements [x, y, t, T]
        cfg: Configuration

    Returns:
        pinn_params: Trained parameters (nn weights + alpha)
        losses: Dictionary of loss histories
    """
    key = jax.random.key(cfg.seed)
    pinn_params = init_pinn_params(cfg)
    adam_state = init_adam(pinn_params)

    losses = {"total": [], "data": [], "physics": [], "ic": [], "bc": []}

    #######################################################################
    # Oppgave 5.3: Start
    #######################################################################

    # Update the nn_params and losses dictionary

    # Gjenbruker mye kode fra train_nn():

    def objective_fn(pinn_params, ic_epoch, interior_epoch, bc_epoch): #objektivfunksjonen 
        # tap for sensordata
        l_data = data_loss(pinn_params["nn"], sensor_data, cfg) #må se hvordan andrea lager dictionaryen

        # tap for ic
        l_ic = ic_loss(pinn_params["nn"], ic_epoch, cfg)    #må se hvordan andrea setter opp dictionaryen

        # tap for fysikken
        l_ph = physics_loss(pinn_params, interior_epoch, cfg)

        # tap for randbetingelser
        l_bc = bc_loss(pinn_params, bc_epoch, cfg)

        # regner ut vektet tap etter ligning (16) under 6.1
        l_total = (
            cfg.lambda_data * l_data + 
            cfg.lambda_ic * l_ic + 
            cfg.lambda_physics * l_ph + 
            cfg.lambda_bc * l_bc)           #Skriver litt ryddigere hehe

        return l_total, (l_data, l_ic, l_ph, l_bc)

    #bruker just in time for å evaluere raskere
    @jit 
    def train_step(pinn_params, ic_epoch, interior_epoch, bc_epoch, adam_state):
        # Evaluer objektivfunksjon og dens gradient (likt som i train_nn())
        (l_total, (l_data, l_ic, l_ph, l_bc)), grads = jax.value_and_grad(
            objective_fn, has_aux=True
            )(pinn_params, ic_epoch, interior_epoch, bc_epoch)

        # Oppdaterer parametre ved å ta steg i Adam-algoritme
        # adam_state: vekter som oppdateres for hvert steg
        # grads: gradienten av objective_fn med respekt til pinn_params
        pinn_params, adam_state = adam_step(pinn_params, grads, adam_state, lr=cfg.learning_rate)

        return pinn_params, adam_state, l_total, l_data, l_ic, l_ph, l_bc
    
    # Tar med fin progress-bar:)
    for _ in tqdm(range(cfg.num_epochs), desc="Training PINN"):
        # 1. Sampler posisjoner hvor ic (initial conditions) skal evalueres
        interior_epoch, key = sample_interior(key, cfg)
        ic_epoch, key = sample_ic(key, cfg)
        bc_epoch, key = sample_bc(key, cfg)

        # kaller jit-evaluerte funksjonen
        pinn_params, adam_state, l_total, l_data, l_ic, l_ph, l_bc = train_step(
            pinn_params, ic_epoch, interior_epoch, bc_epoch, adam_state
            )

        # 4. Lagrer tapene for logging (inni løkken så gjøres hver epoke)
        losses["total"].append(l_total)
        losses["data"].append(l_data)
        losses["physics"].append(l_ph)
        losses["ic"].append(l_ic)
        losses["bc"].append(l_bc)

    #######################################################################
    # Oppgave 5.3: Slutt
    #######################################################################

    return pinn_params, {k: jnp.array(v) for k, v in losses.items()}
